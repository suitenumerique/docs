# Groceries

Amount: $150.00