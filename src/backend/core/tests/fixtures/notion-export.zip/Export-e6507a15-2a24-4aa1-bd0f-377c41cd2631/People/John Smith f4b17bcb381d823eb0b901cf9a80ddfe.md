# John Smith

Email: john@smith.com
Membership Type: Workspace owner
Person: John Smith