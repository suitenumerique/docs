# Check the box to mark items as done

Due date: September 24, 2026
Status: Done
Assignee: John Smith