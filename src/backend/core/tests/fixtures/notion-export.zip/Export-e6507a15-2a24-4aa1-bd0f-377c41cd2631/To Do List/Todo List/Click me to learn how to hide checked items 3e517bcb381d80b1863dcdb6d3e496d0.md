# Click me to learn how to hide checked items

Due date: September 24, 2026
Status: Not started
Assignee: John Smith

From the list, click the ‣ button to change your filters.

![image.png](Click%20me%20to%20learn%20how%20to%20hide%20checked%20items/image.png)

Select “Status”. 

![image.png](Click%20me%20to%20learn%20how%20to%20hide%20checked%20items/image%201.png)

Then check “To Do” and “In Progress” to only see unchecked items in the list. Click “Save for everyone” to finish.

![image.png](Click%20me%20to%20learn%20how%20to%20hide%20checked%20items/image%202.png)

<aside>
<img src="https://app.notion.com/icons/notion_gray.svg" alt="https://app.notion.com/icons/notion_gray.svg" width="40px" />

**Notion Tip**

You can keep track of all sorts of other information about your to dos!

Click “➕ Add a property” to see all the other things you can do.

</aside>