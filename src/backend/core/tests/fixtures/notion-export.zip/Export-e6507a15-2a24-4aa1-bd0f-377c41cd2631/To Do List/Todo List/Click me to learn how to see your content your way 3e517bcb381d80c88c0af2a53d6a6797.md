# Click me to learn how to see your content your way

Due date: September 25, 2026
Status: Not started
Assignee: John Smith

Your content can be shown in countless ways within Notion. Try adding a new **view** to the To Do List database to render your content how you want.

Hover over the “Todo” and “Done” view tabs and click the ‣ to select a new view

![image.png](Click%20me%20to%20learn%20how%20to%20see%20your%20content%20your%20way/image.png)

Select **Board** (or whatever view you’d prefer to select!). This adds a new view and can always be undone.

![image.png](Click%20me%20to%20learn%20how%20to%20see%20your%20content%20your%20way/image%201.png)

Now see your tasks in a board view! Try drag and dropping tasks into done to mark them as completed.

![image.png](Click%20me%20to%20learn%20how%20to%20see%20your%20content%20your%20way/image%202.png)