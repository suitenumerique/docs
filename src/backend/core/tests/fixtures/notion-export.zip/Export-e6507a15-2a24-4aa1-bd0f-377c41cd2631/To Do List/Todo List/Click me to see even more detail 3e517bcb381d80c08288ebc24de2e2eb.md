# Click me to see even more detail

Due date: September 24, 2026
Status: Not started
Assignee: John Smith

Every item in your to do database table has a page that you can edit with content blocks (things like text, bullets, images etc.) - it’s just like editing any other document.

Try the following:

- [ ]  Click anywhere and start typing
- [ ]  Type the `/` key to add all kinds of content — headers, pages, etc.
    
    (Here’s an [Example sub-page](Click%20me%20to%20see%20even%20more%20detail/Example%20sub-page%203e517bcb381d803d956ad01de5e84f83.md)!)
    
- [ ]  Hover over this line, click and hold the : then drag to move it around

<aside>
<img src="https://app.notion.com/icons/notion_gray.svg" alt="https://app.notion.com/icons/notion_gray.svg" width="40px" />

This Database is configured as a Tasks database which allows its contents to appear on your Home tab. All tasks will make their way there. 

https://www.notion.com/help/guides/give-your-to-dos-a-home-with-task-databases

</aside>