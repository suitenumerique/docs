# Click the blue New button to add a task

Due date: September 24, 2026
Status: Not started
Assignee: John Smith