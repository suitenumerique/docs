# Click the due date to change it

Due date: September 24, 2026
Status: Not started
Assignee: John Smith