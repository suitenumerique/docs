# See finished items in the “Done” view

Due date: September 24, 2026
Status: Not started
Assignee: John Smith

A “view” is a way to look at your data. It can be simple as preset filters to a full calendar of events — all using the same underlying data. 

Click **Done** view to see just your finished tasks.

![image.png](See%20finished%20items%20in%20the%20%E2%80%9CDone%E2%80%9D%20view/image.png)